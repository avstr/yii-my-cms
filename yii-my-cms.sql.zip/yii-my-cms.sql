-- phpMyAdmin SQL Dump
-- version 3.2.3
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 07, 2014 at 07:09 PM
-- Server version: 5.1.40
-- PHP Version: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `yii-my-cms`
--

-- --------------------------------------------------------

--
-- Table structure for table `cms_news`
--

CREATE TABLE IF NOT EXISTS `cms_news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `title` varchar(255) NOT NULL,
  `shorh_desc` text NOT NULL,
  `description` text NOT NULL,
  `picture` varchar(255) NOT NULL,
  `hidden` enum('yes','no') NOT NULL DEFAULT 'no',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=27 ;

--
-- Dumping data for table `cms_news`
--

INSERT INTO `cms_news` (`id`, `date`, `title`, `shorh_desc`, `description`, `picture`, `hidden`) VALUES
(23, '2013-12-27 00:00:00', 'sgfdsgf', 'sgsdg', '<p>\r\n	sgdsfg</p>\r\n', '', 'no'),
(22, '2013-12-27 00:00:00', 'dhd', 'dhdfh', '<p>\r\n	dhdhdh</p>\r\n', '', 'no'),
(21, '2013-12-27 00:00:00', 'dhd', 'dhdfgh', '<p>\r\n	dhdfh</p>\r\n', '', 'no'),
(20, '2013-12-27 00:00:00', 'dhgg', 'dhgh', '<p>\r\n	dhhf</p>\r\n', '', 'no'),
(19, '2013-12-27 00:00:00', 'fhdf', 'dhdfh', '<p>\r\n	dhdfh</p>\r\n', '', 'yes'),
(18, '2013-12-27 00:00:00', 'ghf', 'hfhd', '<p>\r\n	ghfh</p>\r\n', '', 'yes'),
(16, '2013-12-25 00:00:00', 'fdsf', 'sdfsdf', 'afsadf', '16.png', 'yes'),
(17, '2014-01-08 00:00:00', 'gfd', 'dgd', '<p>\r\n	fgd</p>\r\n', '17.png', 'no'),
(24, '2013-12-27 00:00:00', 'sgsdg', 'sfgfsdg', '<p>\r\n	sgsdfgf</p>\r\n', '', 'yes'),
(25, '2013-12-27 00:00:00', 'sgsd', 'sgsg', '<p>\r\n	sgsdg</p>\r\n', '', 'yes'),
(26, '2013-12-27 00:00:00', 'sgsg', 'sgsfg', '<p>\r\n	sgfgs</p>\r\n', '', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `cms_page`
--

CREATE TABLE IF NOT EXISTS `cms_page` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL,
  `position` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  `parents` varchar(255) NOT NULL,
  `type` enum('static','URL') NOT NULL,
  `hidden` enum('yes','no') NOT NULL,
  `alias` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `meta_d` varchar(255) NOT NULL,
  `meta_k` varchar(255) NOT NULL,
  `meta_t` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `URL` varchar(255) NOT NULL,
  `content` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=67 ;

--
-- Dumping data for table `cms_page`
--

INSERT INTO `cms_page` (`id`, `pid`, `position`, `level`, `parents`, `type`, `hidden`, `alias`, `title`, `meta_d`, `meta_k`, `meta_t`, `description`, `URL`, `content`) VALUES
(65, 0, 2, 1, '/', 'URL', 'no', 'news', 'Новости', '', '', '', '', 'news/index', ''),
(64, 62, 1, 3, '/61/62/', 'static', 'no', '765754', 'страница 1.2.1', '', '', '', '', '', ''),
(62, 61, 4, 2, '/61/', 'static', 'no', '5453', 'страница 2.1', '', '', '', '', '', ''),
(66, 0, 1, 1, '/', 'URL', 'no', 'response', 'Отзывы', '', '', '', '', 'response', ''),
(63, 0, 17, 1, '/', 'static', 'no', '56346', 'страница 3', '', '', '', '', '', ''),
(61, 0, 11, 1, '/', 'static', 'no', '757', 'страница 2', '', '', '', '', '', ''),
(60, 0, 15, 1, '/', 'static', 'no', '65654', 'страница 1', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `cms_response`
--

CREATE TABLE IF NOT EXISTS `cms_response` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `text` text NOT NULL,
  `answer` text NOT NULL,
  `hidden` enum('yes','no') NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `cms_response`
--

INSERT INTO `cms_response` (`id`, `date`, `name`, `email`, `title`, `text`, `answer`, `hidden`) VALUES
(1, '2014-01-04 00:00:00', 'Настя', 'avstr@list.ru', 'Сайт', 'Очень хороший сайт', '', 'no'),
(2, '2014-01-07 00:00:00', 'Лена', 'avstr@list.ru', 'Тема 1', 'Текст отзыва 1', '', 'no'),
(6, '2014-01-07 00:00:00', 'Настя', 'avstr@list.ru', 'dgfdf', 'dsfgdg', '<p>\r\n	ывыв аыва выаы&nbsp;<img alt="" /><img alt="" height="255" src="/upload/userfiles/images/88c3cf51a0c263673bd32b309d87b476.png" width="670" /><img alt="" height="255" src="/upload/userfiles/images/88c3cf51a0c263673bd32b309d87b476.png" width="670" /></p>\r\n', 'no'),
(7, '2014-01-07 01:08:07', 'Настя', 'avstr@list.ru', 'dgfdf', 'dsfgdg', '', 'yes'),
(8, '2014-01-07 17:08:02', 'ваваы', 'ffff@ddf.ru', 'dfsf', 'sdsfd', '', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `cms_setting`
--

CREATE TABLE IF NOT EXISTS `cms_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sizeSideNewsPicture` int(11) NOT NULL,
  `sizeSideSmallNewsPicture` int(11) NOT NULL,
  `hiddenNewResponse` enum('yes','no') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `cms_setting`
--

INSERT INTO `cms_setting` (`id`, `sizeSideNewsPicture`, `sizeSideSmallNewsPicture`, `hiddenNewResponse`) VALUES
(1, 600, 150, 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `cms_user`
--

CREATE TABLE IF NOT EXISTS `cms_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `secondname` varchar(255) NOT NULL,
  `surname` varchar(255) NOT NULL,
  `login` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created` int(11) NOT NULL,
  `role` enum('admin','user') NOT NULL,
  `ban` enum('yes','no') NOT NULL,
  `email` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `cms_user`
--

INSERT INTO `cms_user` (`id`, `name`, `secondname`, `surname`, `login`, `password`, `created`, `role`, `ban`, `email`) VALUES
(7, 'Анастасия', 'Владимировна', 'Стройкова', 'admin', '21232f297a57a5a743894a0e4a801fc3', 0, 'admin', 'no', ''),
(8, 'Елена', '', 'Еше', 'lena', 'f5a8e923f8cd24b56b3bab32358cc58a', 1386579502, 'admin', 'no', '111@kkk.ru');
