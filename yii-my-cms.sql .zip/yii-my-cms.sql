-- phpMyAdmin SQL Dump
-- version 3.2.3
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 27, 2014 at 05:48 PM
-- Server version: 5.1.40
-- PHP Version: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `yii-my-cms`
--

-- --------------------------------------------------------

--
-- Table structure for table `cms_comment`
--

CREATE TABLE IF NOT EXISTS `cms_comment` (
  `id` bigint(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL,
  `parents` varchar(255) NOT NULL,
  `level` int(11) NOT NULL,
  `module_name` varchar(255) NOT NULL,
  `object_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `title` varchar(255) NOT NULL,
  `comment` text NOT NULL,
  `hidden` enum('yes','no') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `cms_comment`
--

INSERT INTO `cms_comment` (`id`, `pid`, `parents`, `level`, `module_name`, `object_id`, `user_id`, `date`, `title`, `comment`, `hidden`) VALUES
(18, 0, '/', 1, 'news', 26, 7, '2014-01-21 10:49:09', 'ЙЦУЦЙ', 'УЦцу', 'no'),
(19, 18, '/18/', 2, 'news', 26, 7, '2014-01-21 18:43:17', '<script>alert(1)</script>', '<script>alert(1)</script>', 'no'),
(20, 18, '/18/', 2, 'news', 26, 7, '2014-01-21 19:26:51', '2 комментарий', '2 комментарий', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `cms_news`
--

CREATE TABLE IF NOT EXISTS `cms_news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `title` varchar(255) NOT NULL,
  `shorh_desc` text NOT NULL,
  `description` text NOT NULL,
  `picture` varchar(255) NOT NULL,
  `hidden` enum('yes','no') NOT NULL DEFAULT 'no',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=27 ;

--
-- Dumping data for table `cms_news`
--

INSERT INTO `cms_news` (`id`, `date`, `title`, `shorh_desc`, `description`, `picture`, `hidden`) VALUES
(23, '2013-12-27 00:00:00', 'sgfdsgf', 'sgsdg', '<p>\r\n	sgdsfg</p>\r\n', '', 'no'),
(22, '2013-12-27 00:00:00', 'dhd', 'dhdfh', '<p>\r\n	dhdhdh</p>\r\n', '', 'no'),
(21, '2013-12-27 00:00:00', 'dhd', 'dhdfgh', '<p>\r\n	dhdfh</p>\r\n', '', 'no'),
(20, '2013-12-27 00:00:00', 'dhgg', 'dhgh', '<p>\r\n	dhhf</p>\r\n', '', 'no'),
(19, '2013-12-27 00:00:00', 'fhdf', 'dhdfh', '<p>\r\n	dhdfh</p>\r\n', '', 'yes'),
(18, '2013-12-27 00:00:00', 'ghf', 'hfhd', '<p>\r\n	ghfh</p>\r\n', '', 'yes'),
(16, '2013-12-25 00:00:00', 'fdsf', 'sdfsdf', 'afsadf', '16.png', 'yes'),
(17, '2014-01-08 00:00:00', 'gfd', 'dgd', '<p>\r\n	fgd</p>\r\n', '17.png', 'no'),
(24, '2013-12-27 00:00:00', 'sgsdg', 'sfgfsdg', '<p>\r\n	sgsdfgf</p>\r\n', '', 'yes'),
(25, '2013-12-27 00:00:00', 'sgsd', 'sgsg', '<p>\r\n	sgsdg</p>\r\n', '', 'yes'),
(26, '2013-12-27 00:00:00', 'sgsg', 'sgsfg', '<p>\r\n	sgfgs</p>\r\n', '', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `cms_page`
--

CREATE TABLE IF NOT EXISTS `cms_page` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL,
  `position` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  `parents` varchar(255) NOT NULL,
  `type` enum('static','URL') NOT NULL,
  `hidden` enum('yes','no') NOT NULL,
  `alias` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `meta_d` varchar(255) NOT NULL,
  `meta_k` varchar(255) NOT NULL,
  `meta_t` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `URL` varchar(255) NOT NULL,
  `content` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=69 ;

--
-- Dumping data for table `cms_page`
--

INSERT INTO `cms_page` (`id`, `pid`, `position`, `level`, `parents`, `type`, `hidden`, `alias`, `title`, `meta_d`, `meta_k`, `meta_t`, `description`, `URL`, `content`) VALUES
(68, 0, 6, 1, '/', 'URL', 'no', 'registration', 'Регистрация', '', '', '', '', 'site/registration', ''),
(67, 0, 2, 1, '/', 'static', 'no', 'news-response', 'Новости Отзывы', '', '', '', 'Новости и отзывы', '', ''),
(65, 67, 1, 2, '/67/', 'URL', 'no', 'news', 'Новости', '', '', '', '', 'news/index', ''),
(64, 62, 1, 3, '/61/62/', 'static', 'no', '765754', 'страница 2.1.1', '', '', '', '', '', '<p>\r\n	Страница 2.1.1</p>\r\n'),
(62, 61, 4, 2, '/61/', 'static', 'no', '5453', 'страница 2.1', '', '', '', '', '', ''),
(66, 67, 3, 2, '/67/', 'URL', 'no', 'response', 'Отзывы', '', '', '', '', 'response', ''),
(61, 0, 5, 1, '/', 'static', 'no', '757', 'страница 2', '', '', '', '', '', '<p>\r\n	Очень интересный материал о сайте</p>\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `cms_response`
--

CREATE TABLE IF NOT EXISTS `cms_response` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `text` text NOT NULL,
  `answer` text NOT NULL,
  `hidden` enum('yes','no') NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `cms_response`
--

INSERT INTO `cms_response` (`id`, `date`, `name`, `email`, `title`, `text`, `answer`, `hidden`) VALUES
(6, '2014-01-07 00:00:00', 'Настя', 'avstr@list.ru', 'dgfdf', 'dsfgdg', '<p>\r\n	ывыв аыва выаы&nbsp;<img alt="" /><img alt="" height="255" src="/upload/userfiles/images/88c3cf51a0c263673bd32b309d87b476.png" width="670" /><img alt="" height="255" src="/upload/userfiles/images/88c3cf51a0c263673bd32b309d87b476.png" width="670" /></p>\r\n', 'no'),
(7, '2014-01-07 00:00:00', 'Настя', 'avstr@list.ru', 'dgfdf', 'dsfgdg', '', 'no'),
(9, '2014-01-15 14:51:17', 'gdfgd', 'sdfg@fsdf.rt', 'erewr', 'werwrwe', '', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `cms_setting`
--

CREATE TABLE IF NOT EXISTS `cms_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `sizeSideNewsPicture` int(11) NOT NULL,
  `sizeSideSmallNewsPicture` int(11) NOT NULL,
  `hiddenNewResponse` enum('yes','no') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `cms_setting`
--

INSERT INTO `cms_setting` (`id`, `email`, `sizeSideNewsPicture`, `sizeSideSmallNewsPicture`, `hiddenNewResponse`) VALUES
(1, 'avstr@list.ru', 600, 150, 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `cms_user`
--

CREATE TABLE IF NOT EXISTS `cms_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` enum('verify','no_verify','deleted','banned') NOT NULL,
  `secure_code` varchar(255) NOT NULL,
  `time_secure_code` datetime DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `secondname` varchar(255) NOT NULL,
  `surname` varchar(255) NOT NULL,
  `login` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created` int(11) NOT NULL,
  `role` enum('admin','user') NOT NULL,
  `ban` enum('yes','no') NOT NULL,
  `email` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `cms_user`
--

INSERT INTO `cms_user` (`id`, `status`, `secure_code`, `time_secure_code`, `name`, `secondname`, `surname`, `login`, `password`, `created`, `role`, `ban`, `email`) VALUES
(7, 'verify', '', '0000-00-00 00:00:00', 'Анастасия', 'Владимировна', 'Стройкова', 'admin', '21232f297a57a5a743894a0e4a801fc3', 0, 'admin', 'no', ''),
(8, 'verify', '1d3c07f015840310b629c2949f9fdd6b', '2014-01-28 14:48:44', 'Елена', '', 'Еше', 'lena', '5a760236d900b66a9975b3e47ab33a96', 1386579502, 'admin', 'no', '111@kkk.ru'),
(9, 'no_verify', '', '0000-00-00 00:00:00', 'Настя', '', 'Капушкина', 'Настюля', 'd9b1d7db4cd6e70935368a1efb10e377', 1390390567, 'user', 'no', 'avstr@list.ru'),
(10, 'no_verify', '', '0000-00-00 00:00:00', 'fd', '', 'afa', 'sdfa', 'd9b1d7db4cd6e70935368a1efb10e377', 1390393233, 'user', 'no', 'sf@gdsf.fd'),
(11, 'verify', '957ba5c9ea63c0112327a8eac6bc7285', '0000-00-00 00:00:00', 'sds', '', 'ada', 'asdsa', 'c20ad4d76fe97759aa27a0c99bff6710', 1390396032, 'user', 'no', 'asdsad@kkk.oi'),
(12, 'verify', 'dd0859bc5e305510cae3af364fadc5d7', '0000-00-00 00:00:00', 'sds', '', 'ada', 'asdsa1', 'c20ad4d76fe97759aa27a0c99bff6710', 1390396312, 'user', 'no', 'asdsad@kkk.oi1'),
(13, 'verify', '92070615cdf96b2be3b91dd3a803fe55', '0000-00-00 00:00:00', 'sds', '', 'ada', 'asdsa2', 'c20ad4d76fe97759aa27a0c99bff6710', 1390396376, 'user', 'no', 'asdsad@kkk.o2'),
(14, 'verify', '1a4da97da9ff9c503d2ca0b011034a7b', '0000-00-00 00:00:00', 'sds', '', 'ada', 'asdsa3', 'c20ad4d76fe97759aa27a0c99bff6710', 1390396639, 'user', 'no', 'asdsad@kkk.o3'),
(15, 'verify', 'b9834d5bc1758e062257aa95398fcda6', '0000-00-00 00:00:00', 'sds', '', 'ada', 'asdsa4', 'c20ad4d76fe97759aa27a0c99bff6710', 1390397118, 'user', 'no', 'asdsad@kkk.o4'),
(16, 'verify', 'f96015babda1ed053930828be2113db0', '0000-00-00 00:00:00', 'sds', '', 'ada', 'asdsa5', 'c20ad4d76fe97759aa27a0c99bff6710', 1390397175, 'user', 'no', 'asdsad@kkk.o5'),
(17, 'verify', '665f3271141a27d1e7cffecab2cf4ace', '0000-00-00 00:00:00', 'sds', '', 'ada', 'asdsa6', 'c20ad4d76fe97759aa27a0c99bff6710', 1390397260, 'user', 'no', 'asdsad@kkk.o6'),
(1, 'verify', '', '0000-00-00 00:00:00', 'sdas', '', 'ada', 'ada', '28c8edde3d61a0411511d3b1866f0636', 1390397527, 'user', 'no', 'avstr@list.ru1'),
(19, 'no_verify', 'ab860ac77827673b56d5475afffe4571', '2014-01-28 14:36:39', '', '', '', '', 'd41d8cd98f00b204e9800998ecf8427e', 1390818999, 'user', 'yes', '111@kkk.ru');
